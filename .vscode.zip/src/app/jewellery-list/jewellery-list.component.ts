import { Component, inject } from '@angular/core';
import { CommonService } from '../Service/common.service';
import { CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatPaginatorModule } from '@angular/material/paginator';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
@Component({
  selector: 'app-jewellery-list',
  standalone: true,
  imports: [CommonModule, FormsModule, MatSelectModule, MatPaginatorModule, MatInputModule, MatFormFieldModule, MatCheckboxModule],
  templateUrl: './jewellery-list.component.html',
  styleUrl: './jewellery-list.component.scss'

})
export class JewelleryListComponent {
  commonService = inject(CommonService)

  productList: any[] = []
  router = inject(Router)
  activate = inject(ActivatedRoute)

  //Profile
  token: string | null = ""
  userId: string | null = ""
  photo: string | null = ""

  //categories
  categoric: string = ""


  ngOnInit(): void {
    const token = localStorage.getItem('token')
    const userId = localStorage.getItem('userId')
    const photo = localStorage.getItem('photo')
    this.token = token
    this.userId = userId
    this.photo = photo
    this.list()
    this.categories()
  }
  list(): void {
    const user = parseInt(localStorage.getItem('userId')!)
    const products = {
      "search": "",
      "categoryId": -1,
      "subCategoryId": -1,
      "inventoryType": 0,
      "employeeId": user,
    }
    this.commonService.list({ data: this.commonService.encryptData(products) }).subscribe({
      next: (res: any) => {
        const response = this.commonService.decryptData({ data: res })
        this.productList = response
        console.log(response);
      }
    });
  }



  // filter

  // filterId: string = ""

  // filterData(event: any): void {
  //   let filter = event.target.value
  //   const data = {
  //     "employeeId": 1
  //   }
  //   this.commonService.metalTypes({ data: this.commonService.encryptData(data) }).subscribe({
  //     next: (res: any) => {
  //       const response = this.commonService.decryptData({ data: res })
  //       filter = response
  //       this.filterId = filter
  //       console.log(this.filterId);
  //     }
  //   });
  // }

  // categories

  categoryId: any = -1
  categoryType: any = null

  categories(): void {
    const categories = {
      "employeeId": 1
    }
    this.commonService.categories({ data: this.commonService.encryptData(categories) }).subscribe({
      next: (res: any) => {
        const response = this.commonService.decryptData({ data: res })
        this.categoryType = response
      }
    });
    this.list()
  }

  filterProduct(event: any) {
    this.categoryId = event.target.value
    this.list()

  }

  //search
  // searchNg: any | null = null
  // productListName: string = ''
  // search(): void {
  //   const productListName = this.productList
  //   console.log(productListName);

  //   this.activate.paramMap.subscribe({
  //     next: (() => {

  //     })
  //   })

  // }
}
