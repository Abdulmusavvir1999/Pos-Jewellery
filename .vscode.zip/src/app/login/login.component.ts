import { Component, inject } from '@angular/core';
import { CommonService } from '../Service/common.service';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  EDService = inject(CommonService)
  activate = inject(ActivatedRoute)
  router = inject(Router)

  token: string = ""
  employeeId: string = ""

  image: string | null = null
  signIn(): void {
    const user = {
      "username": "admin",
      "password": "1234",
      "inventoryType": "0",
    }
    this.EDService.login({ data: this.EDService.encryptData(user) }).subscribe({
      next: (res: any) => {
        const response = this.EDService.decryptData({ data: res })
        localStorage.setItem("token", response.token),
          localStorage.setItem("userId", response.employeeId),
          localStorage.setItem("photo", response.photo),
          this.router.navigateByUrl('products/pos')
      }
    });

  }



}
