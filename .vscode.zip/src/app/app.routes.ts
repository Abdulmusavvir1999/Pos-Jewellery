import { Routes } from '@angular/router';
import { JewelleryListComponent } from './jewellery-list/jewellery-list.component';
import { LoginComponent } from './login/login.component';

export const routes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'products/pos', component: JewelleryListComponent },
];
