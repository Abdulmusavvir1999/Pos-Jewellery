export const environment = {
    SECRETKEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6InN1cGVyQGdtYWlsLmNvbSIsInBhc3N3b3JkIjoiMTIzNCIsImlhdCI6MTY4MDA3NTg3OH0.NwJj0vqe_GFnLjXarCwz3zTz2mA6ywaLyJfNj0SaLXA',
    BASEURL: 'https://adhirstamnode.ahsanapps.com/'
}